#!/usr/bin/env python


import rospy
import sys
import csv
import glob
import sys
import numpy as np
import os

from kinova_scripts.srv import Joint_angles



if __name__ == '__main__':

    try:
	    n = sys.argv[1]
    except:
	    n = 6

    rospy.init_node('joint_angles', argv=sys.argv)

    directory = os.path.dirname(os.path.realpath(__file__))

    angles = np.zeros((1,13))

    with open(directory + '/final_test/test_data/Matrices/Angles_' + str(n) +'.0.csv') as f:
        reader = csv.reader(f)
        for j, row in enumerate(reader):
            for i, col in enumerate(row):
                angles[j][i] = float(col)

    arm_angles = angles[0][:7]
    rospy.wait_for_service('joint_angles')

    set_angles = rospy.ServiceProxy('joint_angles', Joint_angles)

    try:
        answer = set_angles(arm_angles)
    except rospy.ServiceException as e:
        rospy.logwarn('Service call failed for: {0}'.format(e))

    rospy.loginfo( '{0}'.format(answer.success))