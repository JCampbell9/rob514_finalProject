files description:


*image_processing folder: The input chessboard images for the camera calibration algorithm.

*calibresult.png: The result of the camera calibration algorithm, the undistorted chessboard image.

*camera_mtx.npy: The file which stored the camera matrix of the web-camera.

*dist_mtx.npy: The file which stored the distortion coefficients of the web-camera.

*result.png: The resulting image of "identify aruco markers in image.py".

*Test_6.jpg and Test_10.jpg: The input image of "identify aruco markers in image.py".

*camera calibration.py: Using OpenCV to do the camera calibration, and output the undistort image, the camera matrix and the distortion coefficients. 

*identify aruco markers in image.py: Using Test_10.jpg to be the input image and detect all ArUco Markers. Then, according to the requirement to draw the axes and the position, the orientation information of these ArUco Markers.

*identify aruco markers in videoe.py: Using living video to be the input source and detect all ArUco Markers. Then, according to the requirement to draw the axes and the position, the orientation information of these ArUco Markers.
